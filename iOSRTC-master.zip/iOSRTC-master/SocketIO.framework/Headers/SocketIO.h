//
//  SocketIO-iOS.h
//  SocketIO-iOS
//
//  Created by Nacho Soto on 7/11/15.
//
//

#import <UIKit/UIKit.h>

//! Project version number for SocketIO-iOS.
FOUNDATION_EXPORT double SocketIO_iOSVersionNumber;

//! Project version string for SocketIO-iOS.
FOUNDATION_EXPORT const unsigned char SocketIO_iOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SocketIO_iOS/PublicHeader.h>


